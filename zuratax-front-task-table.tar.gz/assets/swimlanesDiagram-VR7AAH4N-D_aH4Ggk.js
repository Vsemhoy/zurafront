import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-oBChb5qS.js";import"./chunk-DU6HZSFF-DJS2FLeB.js";import"./chunk-75Z2AOVW-hG58CoWa.js";import"./chunk-P2QGCYS3-DeFV5ncg.js";import"./chunk-PWAF6VOD-CA9R_rM4.js";import"./chunk-GMAD6QVW-en2-jELo.js";import"./chunk-4HAMMTFA-CeeacIsn.js";import"./chunk-GVQU2GXP-C3Zxhpwy.js";import"./chunk-L3NEJ4N5-xGVbguST.js";import"./chunk-OSK3NFVY-BzBS8FVu.js";import"./dist-BM5pMZer.js";import"./chunk-F27PBJKO-BxjpnBd_.js";import"./chunk-XXDRQBXY-BvKO0v-W.js";import"./chunk-POPQ4Y6H-Ck8SUncZ.js";import{r as t,t as n}from"./chunk-SHT3W25Y-CgjGAfbi.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};